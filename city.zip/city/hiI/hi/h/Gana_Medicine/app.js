const express = require('express');
const mysql = require('mysql');
const session = require('express-session');
const bodyParser = require('body-parser');
const app = express();

const USER_TYPES = {
  ADMIN: 'Administrador',
  READER: 'Leitor',
  DOCTOR: 'Doctor',
};

// Configurar a conexão com o banco de dados MySQL
const db = mysql.createConnection({
host: 'localhost',
user: 'phpmyadmin',
password: 'aluno',
database: 'mydb',
});

db.connect((err) => {
if (err) {
console.error('Erro ao conectar ao banco de dados:', err);
throw err;
}
console.log('Conexão com o banco de dados MySQL estabelecida.');
});

// Configurar a sessão
app.use(
session({
secret: 'aluno',
resave: true,
saveUninitialized: true,
})
);

app.use(bodyParser.urlencoded({ extended: true }));

// Configurar EJS como o motor de visualização
app.set('view engine', 'ejs');

// Middleware para verificar a sessão e o tipo de usuário
const checkUserTypeMiddleware = (allowedUserTypes) => {
  return (req, res, next) => {
    if (req.session.loggedin) {
      const userType = req.session.type;

      if (allowedUserTypes.includes(userType)) {
        // Usuário tem um tipo válido, permitir o acesso à rota
        return next();
      }
    }

    // Usuário não tem uma sessão válida ou o tipo de usuário é inválido
    res.redirect('acessorestrito');
  };
};

// Rotas protegidas pelo tipo de usuário
app.get('/admin', checkUserTypeMiddleware([USER_TYPES.ADMIN]), (req, res) => {
  res.render('admin', { req: req });
});

app.get('/homepaciente', checkUserTypeMiddleware([USER_TYPES.READER]), (req, res) => {
  res.render('homepaciente', { req: req });
});

app.get('/Doctor', checkUserTypeMiddleware([USER_TYPES.DOCTOR]), (req, res) => {
  res.render('Doctor', { req: req });
});


// Rota para a página de login
app.get('/', (req, res) => {
res.render('homepage');
});

app.post('/login', (req, res) => {
  const { username, password, cpf, type } = req.body;
  const query = 'SELECT * FROM pacientes WHERE username = ? AND password = ?';

  db.query(query, [username, password, cpf, type], (err, results) => {
    if (err) {
      console.error('Erro na consulta SQL:', err);
      return res.status(500).send('Erro interno. <a href="/login">Tente novamente</a>');
    }

    if (results.length > 0) {
      const userType = results[0].type;

      if (userType) {
        req.session.loggedin = true;
        req.session.name = username;
        req.session.type = userType;

        switch (userType) {
          case USER_TYPES.ADMIN:
            return res.redirect('/admin');
            case USER_TYPES.DOCTOR:
              return res.redirect('/Doctor');
          case USER_TYPES.READER:
            return res.redirect('/homepaciente');
          default:
            return res.status(400).send('Tipo de usuário desconhecido. <a href="/login">Tente novamente</a>');
        }
      } else {
        return res.status(400).send('Tipo de usuário não encontrado. <a href="/login">Tente novamente</a>');
      }
    } else {
      return res.status(400).send('Credenciais incorretas. <a href="/login">Tente novamente</a>');
    }
  });
});

// Rota para fazer logout
app.get('/logout', (req, res) => {
req.session.destroy(() => {
res.redirect('/');
});
});

app.use(express.static(__dirname + '/'));
app.use(express.static(__dirname + '/img'));

db.connect(err => {
  if (err) {
    console.error('Erro na conexão com o banco de dados:', err);
    return;
  }
  console.log('Conexão com o banco de dados estabelecida.');
});
//configurar EJS como o motor de visualização
app.set('view engine', 'ejs');

// Configurar o Body Parser
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static('views'));
app.get('/',(req, res) => {
  res.render('cadastro');
  });

//rota para a pagina de cadastro
app.get('/cadastro',(req, res) => {
res.render('cadastro');
});

//rotas
app.get('/local',(req, res) => {
  res.render('local');
  });


app.get('/medicos',(req, res) => {
  res.render('medicos');
  });

app.get('/planos',(req, res) => {
  res.render('planos');
  });

  app.get('/duvidas',(req, res) => {
    res.render('duvidas');
    });
    
  
//rota para a pagina de homepaciente
app.get('/homepaciente',(req, res) => {
  res.render('homepaciente');
  });

//rota para a pagina de cadastro consultas
app.get('/cadastroc',(req, res) => {
  res.render('cadastroc');
  });

app.set('view engine','ejs');
app.get('/login', (req, res) => {
res.render('login'); //renders vies/cadastro.ejs
});
app.get('/rota',(req,res)=>{
  res.render('/consultas'); 
});
// Rota de cadastro
app.post('/cadastro', (req, res) => {
  const { username, password, type } = req.body;
  const query = "INSERT INTO pacientes (username, password, type) VALUES (?, ?, ?)";
  db.query(query, [username, password, type] , (err, result) => {
    if (err) {
      console.error('Erro ao cadastrar o usuário:', err);
      res.status(500).send('Erro ao cadastrar o usuário.');
    } else {
      res.redirect('/login')

    }
  });
});

app.get('/cadastroc',(req, res) => {
  res.render('cadastroc');
  });
  
  app.get('/acessorestrito',(req, res) => {
  res.render('acessorestrito');
  });
// ...

// Rota para a página de consultas
app.get('/consultas', (req, res) => {
  res.render('consultas');
});

// Rota para cadastrar uma consulta
app.post('/cadastroc', (req, res) => {
  const { Nome, Data, Hora, Medico} = req.body;
  const query = 'INSERT INTO Consultas (Nome, Data, Hora, Medico) VALUES (?, ?, ?, ? )';
  db.query(query, [Nome, Data, Hora, Medico], (err, result) => {
    if (err) {
      console.error('Erro ao cadastrar a consulta:', err);
      res.status(500).send('Erro ao cadastrar a consulta.');
    } else {
      console.log('Consulta cadastrada com sucesso!');
      res.redirect('/homepaciente'); // Redirect to the /consultas page after successful insertion
    }
  });
});

// READ - Fetch the list of consultations
app.get('/consultas', (req, res) => {
  db.query('SELECT * FROM Consultas', (err, result) => {
    if (err) throw err;
    res.render('consultas', { Consultas: result }); // Pass the "Consultas" variable
  });
});

// ...


app.listen(4000, () => {
console.log('Servidor rodando na porta ');
});

// READ
app.get('/tabconsultas', (req, res) => {
  db.query('SELECT * FROM Consultas', (err, result) => {
    if (err) throw err;
    res.render('tabconsultas', { Consultas: result });
  });
});

// READ
app.get('/tabconsultas2', (req, res) => {
  db.query('SELECT * FROM Consultas', (err, result) => {
    if (err) throw err;
    res.render('tabconsultas2', { Consultas: result });
  });
});
  
  // READ
  app.get('/tabpacientes', (req, res) => {
    db.query('SELECT * FROM pacientes', (err, result) => {
      if (err) throw err;
      res.render('tabpacientes', { pacientes: result });
    });
  
  });
  
 
  

