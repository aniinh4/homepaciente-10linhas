-- phpMyAdmin SQL Dump
-- version 5.1.1deb5ubuntu1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Tempo de geração: 13/12/2023 às 12:27
-- Versão do servidor: 10.6.12-MariaDB-0ubuntu0.22.04.1
-- Versão do PHP: 8.1.2-1ubuntu2.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `mydb`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `Consultas`
--

CREATE TABLE `Consultas` (
  `Nome` varchar(255) NOT NULL,
  `Data` date NOT NULL,
  `Hora` varchar(255) NOT NULL,
  `Medico` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `Consultas`
--

INSERT INTO `Consultas` (`Nome`, `Data`, `Hora`, `Medico`) VALUES
('Adele', '2023-11-15', '13:30', 'Ferreira depois depois das 23'),
('Miguel', '2023-11-08', '10:12', 'Ferreira desocupada'),
('a', '2023-11-01', 'a', 'a'),
('Arnaldo Cunha', '2023-11-01', '12:30', 'Ana Clara F.O'),
('sofia alonzo', '2023-11-16', '13:00', 'Robson SIlva'),
('Gustavo C.', '2023-12-06', '12:30', 'Arnaldo'),
('Arnaldo', '2023-12-07', '13:00', 'Tamara'),
('Ana Julia', '2023-12-01', '12:12', 'Roberto Carlos'),
('Ana Julia', '2023-12-01', '12:12', 'Roberto Carlos'),
('Ana Julia', '2023-12-01', '12:12', 'Roberto Carlos'),
('Guilherme', '2023-12-08', '14:30', 'Médico da '),
('Guilherme', '2023-12-08', '14:32', 'Ana J.'),
('caio santos', '2023-12-20', '10:25', 'pediatra'),
('Ana', '2023-12-05', '12:30', 'Alexandre'),
('ana', '2023-11-27', '13:20', 'fereirra');

-- --------------------------------------------------------

--
-- Estrutura para tabela `pacientes`
--

CREATE TABLE `pacientes` (
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `type` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `pacientes`
--

INSERT INTO `pacientes` (`username`, `password`, `type`) VALUES
('ai', '123', ''),
('ana', '12', ''),
('ana', '12', ''),
(NULL, NULL, ''),
(NULL, NULL, ''),
(NULL, NULL, ''),
(NULL, NULL, ''),
(NULL, NULL, ''),
('a', 'a', ''),
('a', '1', ''),
('a', '1', ''),
('1', '1', ''),
('Ferreira', '123', ''),
('Ferreira', '123', ''),
('admin', '123', ''),
('admin', '1', ''),
('Brito', '123', 'Leitor'),
('a', 'a', 'Leitor'),
('teste', 'teste', 'Leitor'),
('AAA', 'AAA', 'Administrador'),
('Admin', 'admin', 'Administrador'),
('doutor', 'doutor', 'Doctor'),
('ana', 'a', 'Doctor'),
('Arlindo', '123', 'Doctor'),
('admin', '123', 'Administrador'),
('admin', '123', 'Administrador'),
('1', '1', 'Administrador'),
('1', '2', 'Leitor'),
('4', '3', 'Leitor'),
('12', '12', 'Administrador'),
('Aana', '123', 'Doctor'),
('Ferreira', 'analinda', 'Leitor'),
('Ferreiraa', 'aninha', 'Leitor'),
('arnaldo', 'cunha', 'Leitor'),
('Arlindo', 'Ferreira', 'Leitor'),
('ana', 'a', 'Administrador'),
('Aana', '123', 'Administrador'),
('ana', '12', 'Administrador'),
('Nicolas', 'mole', 'Administrador'),
('geriscleia', '123', 'Leitor'),
('sofia', '123', 'Leitor'),
('Dr. Stone', '123', 'Doctor'),
('Admin sergião', '123', 'Administrador'),
('Amanda', '123', 'Doctor'),
('Arthur', '123', 'Leitor'),
('Pedro', '123', 'Leitor'),
('Alindro', '123', 'Leitor'),
('Veiga', '123', 'Administrador'),
('Marcio', '123', 'Administrador'),
('pedro.rodrigues.ribeiro', '123', 'Leitor'),
('paulo.regiani@portalsesisp.org.br', '123', 'Doctor'),
('alvesnick100@yahoo.com', '123', 'Administrador'),
('João', '123', 'Doctor'),
('Gustavo', '123', 'Leitor'),
('Clarke', '123', 'Doctor'),
('Ana J', '123', 'Leitor'),
('Guilherme ', '5555', 'Leitor'),
('ADMIN', '\'1', 'Administrador'),
('caio', '123', 'Leitor'),
('João', '123', 'Doctor'),
('Ana', '123', 'Leitor'),
('caio', '123', 'Administrador'),
('Ferreira', '123', 'Leitor'),
('Ferreira', '123', 'Leitor'),
('Flávia', '123', 'Leitor'),
('Xamuel', '123', 'Leitor'),
('Jorginho', '123', 'Leitor'),
('Nicolas Cardozo', 'punpun', 'Administrador'),
('Doutor', '123', 'Doctor'),
('dante', '123', 'Leitor'),
('Matheus', '123', 'Doctor'),
('Pedro', '123', 'Administrador'),
('Nicolas Cardozo', 'punpun', 'Leitor');

-- --------------------------------------------------------

--
-- Estrutura para tabela `users`
--

CREATE TABLE `users` (
  `name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `users`
--

INSERT INTO `users` (`name`, `password`) VALUES
('zoro', 'aluno'),
('nome', '123');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
